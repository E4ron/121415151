##Установить NodeJS

###Commands

    npm init

    npm install typescript


    